import plot_on_the_go.potg
from plot_on_the_go.potg import Grapher
