# plot-on-the-go
Update a graph while you plot!

## Installation

From PIP:

```
$ pip install plot-on-the-go
```
